using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.TestTools.CodeCoverage.Editor.Tests")]
[assembly: InternalsVisibleTo("Unity.TestTools.CodeCoverage.Editor.Tests.Performance")]
[assembly: InternalsVisibleTo("Unity.TestTools.CodeCoverage.Editor.CoverageStatsSerializer")]
